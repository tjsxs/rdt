import { Component } from '@angular/core';
import { FrontpageService } from '../../services/fontpage.service';

/*temp*/

@Component({
    moduleId: module.id,
    selector: 'home',
    styleUrls: ['home.component.css'],
    templateUrl: 'home.component.html'
})
export class HomeComponent {
    posts:any;
    constructor(private _fps: FrontpageService ){}

    ngOnInit(){
        this.getHomePosts();
    
    }

    getHomePosts(){
        this._fps.getFP()
            .subscribe(posts => this.posts = posts.data.children);
       
    }

}
