import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'comment',
    templateUrl: 'comment.component.html',
})
export class CommentComponent { 

 }
