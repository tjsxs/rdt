import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FrontpageService } from '../../services/fontpage.service';
import { HomeComponent } from '../../components/home/home.component';

import 'rxjs/add/operator/map'

@Component({
    moduleId: module.id,
    selector: 'sub',
    templateUrl: 'subreddit.component.html',
})
export class SubredditComponent implements OnInit { 
    subreddit: string;
    subredditPosts:any[];
    subName: any;

    constructor(
        private _redditService:FrontpageService,
        private _route:ActivatedRoute
    ){}

    ngOnInit(){
        console.log('Sub Component initiated.');
        this._route.params
            .map(params => params['subreddit'])
            .subscribe((subreddit) => {
                    this.subName = subreddit;
                    this._redditService.getSubreddit(subreddit)
                        .subscribe( sposts => {
                            this.subredditPosts = sposts.data.children;
                        })
                });
               
    }

}
