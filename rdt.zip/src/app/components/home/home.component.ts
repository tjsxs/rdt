import { Component } from '@angular/core';
import { FrontpageService } from '../../services/fontpage.service';

@Component({
    moduleId: module.id,
    selector: 'home',
    templateUrl: 'home.component.html'
})
export class HomeComponent {
    posts:any;
    constructor(private _fps: FrontpageService ){}

    ngOnInit(){
        this.getHomePosts();
        console.log('Home Posts: '+this.posts);
    }

    getHomePosts(){
        this._fps.getFP()
            .subscribe(posts => this.posts = posts.data.children);
        console.log('Frontpage data fetched!');
    }

}
